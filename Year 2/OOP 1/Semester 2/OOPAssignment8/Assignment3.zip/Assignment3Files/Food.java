
/**
 * Write a description of class Food here.
 *
 * @author (Ihsan Ullah)
 * @version (Put a version number and a date when you complete it)
 */
public class Food
{
    // instance variables - replace the example below with your own
    

    /**
     * Constructor for objects of class Food
     */
    public Food()
    {
        // we have
        
    }

    
}
