/**
 * @author Luke Gibbons
 * @version 17/10/2018
 */

public class Payment {
    private final Customer customer;
    private String cardType;
    private final long cardNumber;
    private final double totalCost;
    private final String date;
    private Address address;
    private boolean valid = false;

    public Payment(Customer customer, Address address, String cardType, long cardNumber,
                   String date, Order order){
        this.customer = customer;
        this.cardType = cardType;
        this.cardNumber = cardNumber;
        this.date = date;
        this.address = address;
        this.totalCost = order.getOrderCost();

        validateCard();

        if(isValid()){
            paymentVerified(order);
        }
        else{
            order.setStatus("Failed");
        }
    }

    private void validateCard(){
        cardType = cardType.toLowerCase();
        if(cardType.equals("visa") || cardType.equals("mastercard")){
            valid = true;
        }
    }

    public boolean isValid(){
        return valid;
    }

    private void paymentVerified(Order order){
        order.setStatus("Success");
    }
}
