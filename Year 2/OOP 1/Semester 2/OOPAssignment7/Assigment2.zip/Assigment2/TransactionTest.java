/**
 * @author Luke Gibbons
 * @version 17/10/2018
 */

public class TransactionTest {
    /**
     * main method to execute the TransactionTest methods
     */
    public static void main(String[] args)
    {
        TransactionTest test = new TransactionTest();
        test.transaction1(); // calls the method with our test scenario
        test.transaction2();
    }

    public void transaction1(){
        System.out.println("TEST CASE 1");

        Customer customer = new Customer("Niamh", "O'Leary", "niamhol@zmail.com");

        ShoppingCart cart = new ShoppingCart(customer);

        Item item1 = new Item("Pineapple", 1005678);
        item1.setPrice(1);
        cart.addItem(item1);

        Item item2 = new Item("Macbook", 1158692);
        item2.setPrice(1200);
        cart.addItem(item2);

        Item item3 = new Item("Binoculars", 12124218);
        item3.setPrice(80);
        cart.addItem(item3);

        cart.close();

        Order order = new Order(cart);

        Address delivery = new Address();
        delivery.setAddressLine1("Ardcumber");
        delivery.setStreet("Rivercrown");
        delivery.setCity("Sligo");
        delivery.setCountry("Ireland");
        delivery.setZipCode("242424");

        order.setAddress(delivery);

        Payment payment = new Payment(customer, delivery, "VISA", 476947345, "06/06/2018", order);

        Email email = new Email(customer);

        if (order.PaymentSuccessful()){
            email.messageCreator("Success", order);
        }
        else{
            email.messageCreator("Fail", order);
        }

        email.sendEmail();
    }

    public void transaction2(){
        System.out.println("TEST CASE 2");

        Customer customer = new Customer("Andrew", "Flynn", "Aflynn@hotmail.com");
        ShoppingCart cart = new ShoppingCart(customer);

        Item item1 = new Item("Blender", 718977);
        item1.setPrice(40);
        cart.addItem(item1);

        Item item2 = new Item("John Cena 8 inch Figure", 125981);
        item2.setPrice(8);
        cart.addItem(item2);

        Item item3 = new Item("Acoustic Guitar", 772131);
        item3.setPrice(120);
        cart.addItem(item3);

        System.out.println(cart.printItems());

        cart.removeItem(2);

        cart.close();

        Order order = new Order(cart);

        Address delivery = new Address();
        delivery.setAddressLine1("Rathmines");
        delivery.setStreet("Windmill Town");
        delivery.setCity("New York");
        delivery.setCountry("United States of America");
        delivery.setZipCode("90210");

        order.setAddress(delivery);

        Payment payment = new Payment(customer, delivery, "DarkWebCreditCard", 9912302,"11/6/2000", order);

        Email email = new Email(customer);

        if (order.PaymentSuccessful()){
            email.messageCreator("Success", order);
        }
        else{
            email.messageCreator("Fail", order);
        }

        email.sendEmail();

    }
}
