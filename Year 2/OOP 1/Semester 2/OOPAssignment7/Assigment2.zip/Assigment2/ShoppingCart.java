/**
 * @author Luke Gibbons
 * @version 17/10/2018
 */

import java.util.ArrayList;

public class ShoppingCart {
    private String timeStamp;
    private final long cartID;
    private ArrayList<Item> items;
    private int total = 0;
    private Customer customer;
    private boolean CartClosed = false; //boolean for closed() method

    /**
     * Constructor for objects of class ShoppingCart
     */
    public ShoppingCart(Customer customer)
    {
        this.timeStamp = timeStamp;
        this.cartID = makeItemID();
        this.customer = customer;
        items = new ArrayList<>();
    }

    //Create Cart ID
    private long makeItemID(){
        long ID = (long)(1000000000L * Math.random());
        return ID;
    }

    //Cart Functions
    public void addItem(Item item){
        if(!CartClosed){
            items.add(item);
        }
        else System.out.println("Unable to add more items as shopping cart is closed!");
    }

    public void removeItem(int itemIndex){
        if(!CartClosed){
            items.remove(itemIndex);
        }
        else System.out.println("Unable to remove items as shopping cart is closed!");

    }


    public int getTotal(){
        for (Item item: items){
            total += item.getPrice();
        }
        return total;
    }

    public int getCartSize(){return items.size();}

    public Item getItem(int index){
        return items.get(index);
    }

    public long getCartId(){
        return cartID;
    }

    public Customer getCustomer(){
        return customer;
    }

    public String printItems(){
        String yourCart = "Your Shopping Cart \n";
        yourCart += "--------------------------\n";
        for (Item item: items){
            yourCart += item + "\n";
        }
        yourCart += "--------------------------\n";
        yourCart += "Total Price: \t" + getTotal() + "\n";

        return yourCart;

    }

    public void close(){
        CartClosed = true;
    }

    public void clear(){
        items.clear();
    }

}
