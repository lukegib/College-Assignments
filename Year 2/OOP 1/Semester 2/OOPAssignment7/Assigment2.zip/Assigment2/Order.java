/**
 * @author Luke Gibbons
 * @version 17/10/2018
 */

import java.util.ArrayList;

public class Order {
    private final long orderID;
    private final Customer customer;
    private long cartID;
    private ArrayList<Item> orderedItems = new ArrayList<Item>();
    private double orderCost;
    private String status = "Incomplete"; //payment failed & payment successful
    private Address delivery;

    public Order(ShoppingCart cart) {
        orderID = makeOrderID();
        customer = cart.getCustomer();
        cartID = cart.getCartId();

        //populate the orderedItems array
        for(int i=0; i<cart.getCartSize(); i++){
            Item item = cart.getItem(i);
            orderedItems.add(item);
            orderCost += item.getPrice();
        }
        cart.clear();
    }

    public long makeOrderID() {
        long ID = (long) (1000000000L * Math.random());
        return ID;
    }

    public long getOrderID(){
        return orderID;
    }

    public double getOrderCost(){ return orderCost; }

    public void setAddress(Address delivery){
        this.delivery = delivery;
    }


    public void setStatus(String status){
        this.status = status;
    }

    public String getStatus(){
        return status;
    }

    public boolean PaymentSuccessful(){
        return status.equals("Success");
    }

    public String toString(){
        String orderDetails = "Your Order Details\n" ;
        orderDetails += "--------------------------\n";
        orderDetails += "ORDER ID: " + orderID;
        orderDetails += "\n\n";

        for (Item item: orderedItems){
            orderDetails += item + "\n";
        }
        orderDetails +="---------------------------\n";
        orderDetails += "Total Price: \t" + getOrderCost() + "\n";
        orderDetails += "Order status: ";
        orderDetails += getStatus() + "\n\n";

        return orderDetails;

    }
}