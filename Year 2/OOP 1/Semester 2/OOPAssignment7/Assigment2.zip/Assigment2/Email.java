/**
 * @author Luke Gibbons
 * @version 17/10/2018
 */

 class Email {
    private String emailAddress;
    private String fName;
    private String lName;
    private String emailMessage;

    public Email(Customer customer){
        fName = customer.getFirstName();
        lName = customer.getSurName();
        emailAddress = customer.getEmailAddress();
    }

    public void messageCreator(String messageStatus, Order order){
        if(messageStatus.equals("Success")){
            orderSuccessMessage(order);
        }
        else{
            orderFailureMessage(order);
        }
    }

    public void orderSuccessMessage(Order order){
        emailMessage = "To:" + emailAddress + "\n";
        emailMessage += "\nHello " + fName + "\n";
        emailMessage += "We have received your order and are currently getting it ready! It " +
                "should dispatch in a couple of days.\n\n";
        emailMessage += order;

    }

    public void orderFailureMessage(Order order){
        emailMessage = "To:" + emailAddress + "\n\n";
        emailMessage += "Hello " + fName + "\n";
        emailMessage += "There seems to be a problem with your order (num: " + order.getOrderID() +")\n";
        emailMessage += "Please try again later or check with your bank if the problem persists.\n\n";
        emailMessage += order;
    }

    public void sendEmail(){
        System.out.println(emailMessage);
    }

}
