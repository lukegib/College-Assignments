package testingEclipse;

public class person {
	
	int legs = 2;
	int arms = 2;
	int eyes = 2;
	String name;
	String trick;
	
	public person(String name, String trick) {
		this.name = name;
		this.trick = trick;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTrick() {
		return trick;
	}

	public void setTrick(String trick) {
		this.trick = trick;
	}
	
	
	
	
}
