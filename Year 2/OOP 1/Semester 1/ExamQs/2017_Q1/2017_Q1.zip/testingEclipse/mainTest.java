package testingEclipse;

public class mainTest {

	public static void main(String[] args) {
		person matt = new person("Matt", "Juggles");
		System.out.println(matt.getTrick());

	}
	
	

}
