public class BusEireann implements Tripable{

    private order order;

    public void getAllAvailableTrips(){}

    public void bookingTrips(){}
}
