public class CityLink implements Tripable{

    private order order;

    public void getAllAvailableTrips(){}

    public void bookingTrips(){}
}
