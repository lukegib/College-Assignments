public interface Tripable {

    public void getAllAvailableTrips();

    public void bookingTrips();

}
